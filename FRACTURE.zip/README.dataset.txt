# Science Research 2022: Bone Fracture Detection > 2022-12-19 1:01pm
https://universe.roboflow.com/science-research/science-research-2022:-bone-fracture-detection

Provided by a Roboflow user
License: CC BY 4.0

